Vous voulez une fun fact, hier j'ai voulu mettre une border à un tr non collapse, j'ai mis 4h a trouve la solution... et j'ai oublié de transmettre le fichier zip 
:/